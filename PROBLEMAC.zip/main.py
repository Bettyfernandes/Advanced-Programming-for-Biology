#--------------------------------------------------
#              TYPE OF TRIANGULE
#--------------------------------------------------


#Inputs
print("Input the length of the three sides:")
a=float(input())
b=float(input())
c=float(input())


#CONDITIONS

if (a <= 0 or b <= 0 or c <= 0) or (a >= b + c or b >= a + c or c >= a + b): 
    print("Not a triangle")
elif a == b == c: 
    print("Equilateral")
elif a == b or a == c or b == c: 
    print("Isosceles") 
else: 
    print("Scalene")

    