#-------------------------------------------
#             Rectangle area
#-------------------------------------------

#INPUTS

length=int(input())
width=int(input())

#Calculation
area=length*width


#OUTPUTS
print(area)


